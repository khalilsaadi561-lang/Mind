package com.example.ui.cards

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun TarneebGameScreen(
    language: AppLanguage,
    onGameFinished: (score: Int) -> Unit,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedMode by remember { mutableStateOf<GameModeType?>(null) }
    var roomCode by remember { mutableStateOf("") }
    var showModeDialog by remember { mutableStateOf(true) }

    // Game state
    var deck by remember { mutableStateOf(generateStandardDeck()) }
    var playerHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var westHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var northHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var eastHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }

    var currentPhase by remember { mutableStateOf("BIDDING") } // BIDDING, TRUMP_SELECT, PLAYING, ROUND_OVER
    var highestBidder by remember { mutableIntStateOf(0) } // 0: Player, 1: West, 2: North, 3: East
    var winningBid by remember { mutableIntStateOf(7) }
    var selectedTrumpSuit by remember { mutableStateOf<CardSuit?>(null) }

    var turnIndex by remember { mutableIntStateOf(0) } // 0..3
    var playedCardsOnTable by remember { mutableStateOf<Map<Int, PlayingCard>>(emptyMap()) }

    var teamUsTricks by remember { mutableIntStateOf(0) }
    var teamThemTricks by remember { mutableIntStateOf(0) }

    var teamUsScore by remember { mutableIntStateOf(0) }
    var teamThemScore by remember { mutableIntStateOf(0) }

    var activeChatMessage by remember { mutableStateOf<String?>(null) }

    fun startNewRound() {
        val newDeck = generateStandardDeck()
        playerHand = newDeck.subList(0, 13).sortedWith(compareBy({ it.suit.ordinal }, { it.rank.ordinal }))
        westHand = newDeck.subList(13, 26)
        northHand = newDeck.subList(26, 39)
        eastHand = newDeck.subList(39, 52)

        playedCardsOnTable = emptyMap()
        teamUsTricks = 0
        teamThemTricks = 0
        winningBid = 7
        highestBidder = 0
        selectedTrumpSuit = null
        currentPhase = "BIDDING"
        turnIndex = 0
    }

    LaunchedEffect(Unit) {
        startNewRound()
    }

    // Bot Auto Bidding & Card Playing Logic
    fun executeBotTurn() {
        if (currentPhase == "BIDDING") {
            if (turnIndex != 0) {
                coroutineScope.launch {
                    delay(800)
                    // Bot bids or passes
                    val botWillBid = (1..100).random() > 60 && winningBid < 11
                    if (botWillBid) {
                        winningBid += 1
                        highestBidder = turnIndex
                        activeChatMessage = "Bot ${turnIndex}: Bidding $winningBid!"
                    } else {
                        activeChatMessage = "Bot ${turnIndex}: Pass"
                    }
                    delay(500)
                    activeChatMessage = null
                    val nextTurn = (turnIndex + 1) % 4
                    if (nextTurn == 0 && winningBid >= 7) {
                        // Bidding complete
                        if (highestBidder == 0) {
                            currentPhase = "TRUMP_SELECT"
                        } else {
                            selectedTrumpSuit = CardSuit.values().random()
                            currentPhase = "PLAYING"
                            turnIndex = highestBidder
                        }
                    } else {
                        turnIndex = nextTurn
                    }
                }
            }
        } else if (currentPhase == "PLAYING" && turnIndex != 0) {
            coroutineScope.launch {
                delay(900)
                val botHandList = when (turnIndex) {
                    1 -> westHand
                    2 -> northHand
                    else -> eastHand
                }.toMutableList()

                if (botHandList.isNotEmpty()) {
                    val cardToPlay = botHandList.first()
                    botHandList.remove(cardToPlay)

                    when (turnIndex) {
                        1 -> westHand = botHandList
                        2 -> northHand = botHandList
                        else -> eastHand = botHandList
                    }

                    playedCardsOnTable = playedCardsOnTable + (turnIndex to cardToPlay)

                    if (playedCardsOnTable.size == 4) {
                        // Evaluate trick
                        delay(1200)
                        val leadCard = playedCardsOnTable[highestBidder] ?: cardToPlay
                        var winningPlayer = turnIndex
                        var highestValue = -1

                        playedCardsOnTable.forEach { (pIdx, card) ->
                            var valScore = card.rank.value
                            if (card.suit == selectedTrumpSuit) valScore += 100
                            else if (card.suit != leadCard.suit) valScore = 0

                            if (valScore > highestValue) {
                                highestValue = valScore
                                winningPlayer = pIdx
                            }
                        }

                        if (winningPlayer == 0 || winningPlayer == 2) teamUsTricks += 1
                        else teamThemTricks += 1

                        playedCardsOnTable = emptyMap()

                        if (playerHand.isEmpty() && westHand.isEmpty()) {
                            // Round finished
                            currentPhase = "ROUND_OVER"
                            if (highestBidder == 0 || highestBidder == 2) {
                                if (teamUsTricks >= winningBid) teamUsScore += teamUsTricks
                                else teamUsScore -= winningBid
                            } else {
                                if (teamThemTricks >= winningBid) teamThemScore += teamThemTricks
                                else teamThemScore -= winningBid
                            }
                            onGameFinished(teamUsScore * 10)
                        } else {
                            turnIndex = winningPlayer
                        }
                    } else {
                        turnIndex = (turnIndex + 1) % 4
                    }
                }
            }
        }
    }

    LaunchedEffect(turnIndex, currentPhase) {
        executeBotTurn()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF064E3B), Color(0xFF022C22)))
                )
                .padding(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = Localization.getString("game_tarneeb_title", language),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 17.sp
                    )
                    Text(
                        text = if (selectedMode == GameModeType.ONLINE) "Online Room: $roomCode 🌐" else "vs Smart AI Bots 🤖",
                        fontSize = 11.sp,
                        color = Color(0xFFFFD700)
                    )
                }
                IconButton(onClick = { startNewRound() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = Color.White)
                }
            }

            // Scoreboard Bar
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFF10B981)))
                )
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "فريقنا (Us)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "$teamUsScore PTS", color = Color(0xFFFFD700), fontSize = 18.sp, fontWeight = FontWeight.Black)
                        Text(text = "Tricks: $teamUsTricks", color = Color.LightGray, fontSize = 11.sp)
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(36.dp)
                            .background(Color.Gray)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "الطلب (Bid)", color = Color.Gray, fontSize = 11.sp)
                        Text(
                            text = if (selectedTrumpSuit != null) "$winningBid ${selectedTrumpSuit?.symbol}" else "Bid: $winningBid",
                            color = Color(0xFF00F0FF),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(36.dp)
                            .background(Color.Gray)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "الفريق الخصم", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "$teamThemScore PTS", color = Color(0xFFEF4444), fontSize = 18.sp, fontWeight = FontWeight.Black)
                        Text(text = "Tricks: $teamThemTricks", color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Green Playing Felt Table
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF047857)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF059669), Color(0xFF047857)))
                )
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // North Partner
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "👤 الشريك (North)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Row {
                            repeat(northHand.size.coerceAtMost(5)) {
                                PlayingCardView(card = null, isFaceUp = false, modifier = Modifier.size(30.dp, 44.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                            }
                        }
                    }

                    // West Bot
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🤖 West", color = Color.White, fontSize = 11.sp)
                        PlayingCardView(card = null, isFaceUp = false, modifier = Modifier.size(30.dp, 44.dp))
                    }

                    // East Bot
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🤖 East", color = Color.White, fontSize = 11.sp)
                        PlayingCardView(card = null, isFaceUp = false, modifier = Modifier.size(30.dp, 44.dp))
                    }

                    // Played Cards in Table Center
                    Box(
                        modifier = Modifier
                            .size(160.dp, 120.dp)
                            .align(Alignment.Center)
                            .background(Color(0xFF064E3B).copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                            .border(1.dp, Color(0xFF10B981), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        playedCardsOnTable.forEach { (pIdx, card) ->
                            val cardAlign = when (pIdx) {
                                0 -> Alignment.BottomCenter
                                1 -> Alignment.CenterStart
                                2 -> Alignment.TopCenter
                                else -> Alignment.CenterEnd
                            }
                            Box(modifier = Modifier.align(cardAlign).padding(4.dp)) {
                                PlayingCardView(card = card, isFaceUp = true, modifier = Modifier.size(40.dp, 58.dp))
                            }
                        }

                        if (playedCardsOnTable.isEmpty() && currentPhase == "PLAYING") {
                            Text(
                                text = if (turnIndex == 0) "دورك لرمي كرت!" else "انتظار دور اللاعبين...",
                                color = Color.LightGray,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Bidding Control Overlay
                    if (currentPhase == "BIDDING" && turnIndex == 0) {
                        Card(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = Localization.getString("bid_phase", language),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    (7..13).forEach { bidVal ->
                                        Button(
                                            onClick = {
                                                winningBid = bidVal
                                                highestBidder = 0
                                                currentPhase = "TRUMP_SELECT"
                                            },
                                            modifier = Modifier.size(42.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700)),
                                            shape = CircleShape
                                        ) {
                                            Text(text = "$bidVal", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        turnIndex = 1
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                                ) {
                                    Text(Localization.getString("pass", language))
                                }
                            }
                        }
                    }

                    // Trump Selection Overlay
                    if (currentPhase == "TRUMP_SELECT") {
                        Card(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "اختر نوع الطرنيب (Trump Suit):",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    CardSuit.values().forEach { suit ->
                                        Button(
                                            onClick = {
                                                selectedTrumpSuit = suit
                                                currentPhase = "PLAYING"
                                                turnIndex = 0
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                                        ) {
                                            Text(
                                                text = suit.symbol,
                                                color = suit.color,
                                                fontSize = 24.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Player Hand Row (South)
            Text(
                text = "كروتك (Your Hand):",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy((-16).dp)
            ) {
                items(playerHand) { card ->
                    PlayingCardView(
                        card = card,
                        isFaceUp = true,
                        onClick = {
                            if (currentPhase == "PLAYING" && turnIndex == 0 && playedCardsOnTable[0] == null) {
                                playerHand = playerHand - card
                                playedCardsOnTable = playedCardsOnTable + (0 to card)

                                if (playedCardsOnTable.size == 4) {
                                    // evaluate trick
                                } else {
                                    turnIndex = 1
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    if (showModeDialog) {
        GameModeSelectionDialog(
            gameTitle = Localization.getString("game_tarneeb_title", language),
            language = language,
            onSelectMode = { mode, isHost, code ->
                selectedMode = mode
                roomCode = code
                showModeDialog = false
            },
            onDismiss = onBack
        )
    }
}
