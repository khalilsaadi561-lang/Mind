package com.example.ui.games

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import kotlin.random.Random

enum class ShapeType { CIRCLE, SQUARE, STAR, DIAMOND }

data class TargetShape(
    val type: ShapeType,
    val color: Color,
    val nameEn: String,
    val nameAr: String,
    val xRatio: Float,
    val yRatio: Float,
    val sizeDp: Int = 72
)

@Composable
fun SpeedReflexGame(
    language: AppLanguage,
    onGameFinished: (score: Int) -> Unit,
    onBack: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val availableShapes = remember {
        listOf(
            TargetShape(ShapeType.CIRCLE, Color(0xFF00F0FF), "Cyan Circle", "دائرة سماوية", 0.5f, 0.5f),
            TargetShape(ShapeType.SQUARE, Color(0xFFFF007A), "Magenta Square", "مربع أرجواني", 0.3f, 0.4f),
            TargetShape(ShapeType.STAR, Color(0xFFFFD700), "Gold Star", "نجمة ذهبية", 0.7f, 0.6f),
            TargetShape(ShapeType.DIAMOND, Color(0xFF10B981), "Emerald Diamond", "ماس أخضر", 0.4f, 0.7f)
        )
    }

    var gameState by remember { mutableStateOf("READY") } // READY, PLAYING, GAMEOVER
    var score by remember { mutableStateOf(0) }
    var streak by remember { mutableStateOf(0) }
    var lives by remember { mutableStateOf(3) }
    var timeLeftSeconds by remember { mutableStateOf(25) }
    var currentTargetIndex by remember { mutableStateOf(0) }
    var targetOffset by remember { mutableStateOf(Offset(0.5f, 0.5f)) }
    var lastSpawnTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var reactionTimesMs = remember { mutableStateListOf<Long>() }
    var feedbackText by remember { mutableStateOf("") }
    var feedbackColor by remember { mutableStateOf(Color.Green) }

    // Countdown Timer
    LaunchedEffect(gameState) {
        if (gameState == "PLAYING") {
            while (timeLeftSeconds > 0 && gameState == "PLAYING") {
                delay(1000)
                timeLeftSeconds--
            }
            if (timeLeftSeconds <= 0) {
                gameState = "GAMEOVER"
                onGameFinished(score)
            }
        }
    }

    fun spawnNextTarget() {
        currentTargetIndex = Random.nextInt(availableShapes.size)
        // Ensure random positions away from screen boundaries (0.15f to 0.85f)
        targetOffset = Offset(
            x = 0.15f + Random.nextFloat() * 0.70f,
            y = 0.20f + Random.nextFloat() * 0.60f
        )
        lastSpawnTime = System.currentTimeMillis()
    }

    fun handleTap(tappedOnTarget: Boolean) {
        if (gameState != "PLAYING") return

        val reactionMs = System.currentTimeMillis() - lastSpawnTime
        if (tappedOnTarget) {
            reactionTimesMs.add(reactionMs)
            streak++
            val streakBonus = (streak / 3) * 50
            val points = ((1000 - reactionMs).coerceAtLeast(100).toInt()) + streakBonus
            score += points
            feedbackText = if (reactionMs < 300) "⚡ PERFECT! ${reactionMs}ms" else "FAST! ${reactionMs}ms"
            feedbackColor = Color(0xFF00F0FF)
            spawnNextTarget()
        } else {
            streak = 0
            lives--
            feedbackText = "MISSED! -1 Life"
            feedbackColor = Color(0xFFFF007A)
            if (lives <= 0) {
                gameState = "GAMEOVER"
                onGameFinished(score)
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0B061A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1E0B36), Color(0xFF0B061A))
                    )
                )
                .padding(16.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = Localization.getString("game_reflex_title", language),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .background(Color(0xFF2E1065), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "🏆 $score",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFD700),
                        fontSize = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Game Dashboard Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF170F2C), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF332058), RoundedCornerShape(16.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = Color(0xFF00F0FF))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "${timeLeftSeconds}s", fontWeight = FontWeight.Bold, color = Color.White)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = Color(0xFFFFD700))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Streak: ${streak}x", fontWeight = FontWeight.Bold, color = Color(0xFFFFD700))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Lives: ", fontSize = 12.sp, color = Color.Gray)
                    repeat(3) { i ->
                        Text(
                            text = if (i < lives) "❤️" else "🖤",
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Instruction prompt
            if (gameState == "PLAYING") {
                val currentShape = availableShapes[currentTargetIndex]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF221142)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(currentShape.color, Color.White)))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isAr) "انقر على: " else "TAP TARGET: ",
                            fontWeight = FontWeight.Bold,
                            color = Color.LightGray,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (isAr) currentShape.nameAr else currentShape.nameEn,
                            fontWeight = FontWeight.ExtraBold,
                            color = currentShape.color,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        if (feedbackText.isNotEmpty()) {
                            Text(
                                text = feedbackText,
                                fontWeight = FontWeight.Bold,
                                color = feedbackColor,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Interactive Play Arena
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF0F081F))
                    .border(1.5.dp, Color(0xFF3B1E6D), RoundedCornerShape(24.dp))
                    .pointerInput(gameState) {
                        detectTapGestures { offset ->
                            if (gameState == "PLAYING") {
                                handleTap(false) // Tapped empty background arena = miss!
                            }
                        }
                    }
            ) {
                when (gameState) {
                    "READY" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ElectricBolt,
                                contentDescription = null,
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = Localization.getString("game_reflex_title", language),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = Localization.getString("game_reflex_desc", language),
                                fontSize = 14.sp,
                                color = Color.LightGray,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(28.dp))
                            Button(
                                onClick = {
                                    score = 0
                                    streak = 0
                                    lives = 3
                                    timeLeftSeconds = 25
                                    reactionTimesMs.clear()
                                    gameState = "PLAYING"
                                    spawnNextTarget()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .height(54.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = Localization.getString("play_now", language),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }

                    "PLAYING" -> {
                        val shape = availableShapes[currentTargetIndex]
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                        ) {
                            // Target Shape positioned using targetOffset
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .align(
                                        androidx.compose.ui.BiasAlignment(
                                            (targetOffset.x * 2) - 1f,
                                            (targetOffset.y * 2) - 1f
                                        )
                                    )
                                    .clickable {
                                        handleTap(true)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val size = size.minDimension
                                    when (shape.type) {
                                        ShapeType.CIRCLE -> drawCircle(color = shape.color)
                                        ShapeType.SQUARE -> drawRect(color = shape.color)
                                        ShapeType.DIAMOND -> {
                                            val path = Path().apply {
                                                moveTo(size / 2, 0f)
                                                lineTo(size, size / 2)
                                                lineTo(size / 2, size)
                                                lineTo(0f, size / 2)
                                                close()
                                            }
                                            drawPath(path, shape.color)
                                        }
                                        ShapeType.STAR -> {
                                            drawCircle(color = shape.color) // Bright star aura
                                        }
                                    }
                                }
                                if (shape.type == ShapeType.STAR) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }
                        }
                    }

                    "GAMEOVER" -> {
                        val avgReaction = if (reactionTimesMs.isNotEmpty()) reactionTimesMs.average().roundToInt() else 0
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = Localization.getString("game_over", language),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFFF007A)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "FINAL SCORE: $score",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD700)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Avg Reaction Speed: ${avgReaction}ms",
                                fontSize = 15.sp,
                                color = Color(0xFF00F0FF)
                            )
                            Spacer(modifier = Modifier.height(28.dp))
                            Row {
                                Button(
                                    onClick = {
                                        score = 0
                                        streak = 0
                                        lives = 3
                                        timeLeftSeconds = 25
                                        reactionTimesMs.clear()
                                        gameState = "PLAYING"
                                        spawnNextTarget()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(Localization.getString("play_again", language))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
