package com.example.util

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.delay

object AdMobManager {
    const val APP_ID = "ca-app-pub-9208395103529101~4592114561"
    const val BANNER_AD_UNIT_ID = "ca-app-pub-9208395103529101/2672262306"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-9208395103529101/7733017298"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-9208395103529101/3250846801"

    // Test Ad Unit IDs as fallback for emulators/sandboxes where real live units might return No Fill error
    const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    private var initialized = false

    fun initialize(context: Context) {
        if (!initialized) {
            try {
                MobileAds.initialize(context) { status ->
                    Log.d("AdMobManager", "AdMob MobileAds initialized: $status")
                }
                initialized = true
            } catch (e: Exception) {
                Log.e("AdMobManager", "Error initializing AdMob: ${e.message}")
            }
        }
    }
}

@Composable
fun AdMobBannerView(
    isAdRemoved: Boolean,
    modifier: Modifier = Modifier
) {
    if (isAdRemoved) return

    val context = LocalContext.current
    var isFailedToLoad by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        AdMobManager.initialize(context)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(Color(0xFF101A2E))
            .border(0.5.dp, Color(0xFF334155)),
        contentAlignment = Alignment.Center
    ) {
        if (!isFailedToLoad) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    AdView(ctx).apply {
                        setAdSize(AdSize.BANNER)
                        // Try production unit first, if fails fallback gracefully
                        adUnitId = AdMobManager.BANNER_AD_UNIT_ID
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        adListener = object : com.google.android.gms.ads.AdListener() {
                            override fun onAdFailedToLoad(error: LoadAdError) {
                                Log.w("AdMobBanner", "Banner ad failed to load (${error.message}). Retrying test unit...")
                                // Retry with test unit ID for dev preview compatibility
                                adUnitId = AdMobManager.TEST_BANNER_ID
                                loadAd(AdRequest.Builder().build())
                            }
                        }
                        loadAd(AdRequest.Builder().build())
                    }
                }
            )
        } else {
            // Sleek fallback indicator banner
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp)
            ) {
                Text(
                    text = "AD",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    modifier = Modifier
                        .background(Color(0xFFFFD700), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Mind Clash Sponsors - Get VIP Pass to Remove Ads",
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }
        }
    }
}

@Composable
fun SimulatedInterstitialAdDialog(
    show: Boolean,
    onAdDismissed: () -> Unit
) {
    if (!show) return

    var countdown by remember { mutableStateOf(3) }
    var canClose by remember { mutableStateOf(false) }

    LaunchedEffect(show) {
        while (countdown > 0) {
            delay(1000)
            countdown--
        }
        canClose = true
    }

    Dialog(
        onDismissRequest = { if (canClose) onAdDismissed() },
        properties = DialogProperties(dismissOnBackPress = canClose, dismissOnClickOutside = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF0F172A),
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
                        )
                    )
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SPONSORED AD",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier
                            .background(Color(0xFFFFD700), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    if (canClose) {
                        IconButton(onClick = onAdDismissed) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Ad",
                                tint = Color.White
                            )
                        }
                    } else {
                        Text(
                            text = "Skip in $countdown s",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .background(Color(0xFF312E81), RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF6366F1), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.OndemandVideo,
                            contentDescription = "Ad",
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Mind Clash VIP Pass",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Remove All Ads & Earn 1000 Coins!",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onAdDismissed,
                    enabled = canClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6366F1),
                        disabledContainerColor = Color(0xFF334155)
                    )
                ) {
                    Text(if (canClose) "Continue to Game" else "Please wait...")
                }
            }
        }
    }
}

@Composable
fun RewardedAdVideoDialog(
    show: Boolean,
    language: AppLanguage,
    onRewardEarned: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!show) return

    val context = LocalContext.current
    var isVideoPlaying by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0f) }
    var rewardClaimed by remember { mutableStateOf(false) }

    LaunchedEffect(show) {
        AdMobManager.initialize(context)
        // Try loading real AdMob Rewarded Ad
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            AdMobManager.REWARDED_AD_UNIT_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d("RewardedAd", "Rewarded Ad loaded successfully.")
                    val activity = context as? Activity
                    if (activity != null) {
                        ad.show(activity) { rewardItem ->
                            Log.d("RewardedAd", "User earned reward: ${rewardItem.amount}")
                            rewardClaimed = true
                            onRewardEarned()
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("RewardedAd", "Rewarded Ad failed (${error.message}). Running video simulator...")
                }
            }
        )

        // Simultaneous smooth 5-second simulated rewarded video
        for (i in 1..50) {
            delay(100)
            progress = i / 50f
        }
        isVideoPlaying = false
        if (!rewardClaimed) {
            rewardClaimed = true
            onRewardEarned()
        }
    }

    Dialog(
        onDismissRequest = { if (!isVideoPlaying) onDismiss() },
        properties = DialogProperties(dismissOnBackPress = !isVideoPlaying, dismissOnClickOutside = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF2E1065), Color(0xFF0F172A))
                        )
                    )
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = Localization.getString("free_coins_ad", language),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color(0xFF1E1B4B), RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFFFFD700), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isVideoPlaying) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.size(56.dp),
                                color = Color(0xFFFFD700),
                                trackColor = Color(0xFF334155)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Watching Ad... ${(progress * 100).toInt()}%",
                                fontSize = 14.sp,
                                color = Color.White
                            )
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Reward",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "+100 COINS EARNED!",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFFFD700),
                                fontSize = 20.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    enabled = !isVideoPlaying,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700))
                ) {
                    Text(
                        text = if (!isVideoPlaying) "Claim 100 Coins!" else "Watching Ad...",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
