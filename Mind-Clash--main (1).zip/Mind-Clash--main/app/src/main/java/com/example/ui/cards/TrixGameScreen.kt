package com.example.ui.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class TrixVariant {
    CLASSIC, COMPLEX, COMPLEX_COMPLEX
}

@Composable
fun TrixGameScreen(
    language: AppLanguage,
    onGameFinished: (score: Int) -> Unit,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedMode by remember { mutableStateOf<GameModeType?>(null) }
    var roomCode by remember { mutableStateOf("") }
    var showModeDialog by remember { mutableStateOf(true) }

    var selectedVariant by remember { mutableStateOf(TrixVariant.COMPLEX) }

    // Game Cards
    var playerHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var westHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var northHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var eastHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }

    var turnIndex by remember { mutableIntStateOf(0) }
    var playedCardsOnTable by remember { mutableStateOf<Map<Int, PlayingCard>>(emptyMap()) }

    var playerScore by remember { mutableIntStateOf(0) }
    var botWestScore by remember { mutableIntStateOf(0) }
    var botNorthScore by remember { mutableIntStateOf(0) }
    var botEastScore by remember { mutableIntStateOf(0) }

    var activeContractName by remember { mutableStateOf("COMPLEX ROUND (-75 King ♥, -25 Queens, -10 ♦)") }

    fun startNewGame() {
        val deck = generateStandardDeck()
        playerHand = deck.subList(0, 13).sortedWith(compareBy({ it.suit.ordinal }, { it.rank.ordinal }))
        westHand = deck.subList(13, 26)
        northHand = deck.subList(26, 39)
        eastHand = deck.subList(39, 52)

        playedCardsOnTable = emptyMap()
        turnIndex = 0
    }

    LaunchedEffect(Unit) {
        startNewGame()
    }

    // Bot AI for Trix
    fun executeBotTurn() {
        if (turnIndex != 0) {
            coroutineScope.launch {
                delay(800)
                val currentBotHand = when (turnIndex) {
                    1 -> westHand
                    2 -> northHand
                    else -> eastHand
                }.toMutableList()

                if (currentBotHand.isNotEmpty()) {
                    val cardToPlay = currentBotHand.first()
                    currentBotHand.remove(cardToPlay)

                    when (turnIndex) {
                        1 -> westHand = currentBotHand
                        2 -> northHand = currentBotHand
                        else -> eastHand = currentBotHand
                    }

                    playedCardsOnTable = playedCardsOnTable + (turnIndex to cardToPlay)

                    if (playedCardsOnTable.size == 4) {
                        delay(1200)
                        // Calculate trick penalties
                        var winningPlayer = turnIndex
                        var highestRank = -1

                        playedCardsOnTable.forEach { (pIdx, card) ->
                            if (card.rank.value > highestRank) {
                                highestRank = card.rank.value
                                winningPlayer = pIdx
                            }

                            // Calculate Complex Penalties
                            var penalty = 0
                            if (card.suit == CardSuit.HEARTS && card.rank == CardRank.KING) penalty -= 75
                            if (card.rank == CardRank.QUEEN) penalty -= 25
                            if (card.suit == CardSuit.DIAMONDS) penalty -= 10
                            penalty -= 15 // Trick penalty

                            when (pIdx) {
                                0 -> playerScore += penalty
                                1 -> botWestScore += penalty
                                2 -> botNorthScore += penalty
                                else -> botEastScore += penalty
                            }
                        }

                        playedCardsOnTable = emptyMap()

                        if (playerHand.isEmpty() && westHand.isEmpty()) {
                            onGameFinished(playerScore + 500)
                        } else {
                            turnIndex = winningPlayer
                        }
                    } else {
                        turnIndex = (turnIndex + 1) % 4
                    }
                }
            }
        }
    }

    LaunchedEffect(turnIndex) {
        executeBotTurn()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F0B1E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF2E1065), Color(0xFF0F0B1E)))
                )
                .padding(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = Localization.getString("game_trix_title", language),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Variant: ${selectedVariant.name} • ${if (selectedMode == GameModeType.ONLINE) "Online: $roomCode" else "vs Bots"}",
                        fontSize = 11.sp,
                        color = Color(0xFFEC4899)
                    )
                }
                IconButton(onClick = { startNewGame() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = Color.White)
                }
            }

            // Variant Selector Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                TrixVariant.values().forEach { variant ->
                    val isSel = selectedVariant == variant
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSel) Color(0xFFEC4899) else Color(0xFF1E153B),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedVariant = variant }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = variant.name.replace("_", " "),
                            color = if (isSel) Color.White else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Scores Row
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1F183D))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = " You: $playerScore", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "🤖 W: $botWestScore", color = Color.LightGray, fontSize = 12.sp)
                    Text(text = "🤖 N: $botNorthScore", color = Color.LightGray, fontSize = 12.sp)
                    Text(text = "🤖 E: $botEastScore", color = Color.LightGray, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Trix Playing Felt Table
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E153B)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)))
                )
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Text(
                        text = activeContractName,
                        color = Color(0xFFEC4899),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp)
                    )

                    // Played Cards Center
                    Box(
                        modifier = Modifier
                            .size(160.dp, 120.dp)
                            .align(Alignment.Center)
                            .background(Color(0xFF2E1065).copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                            .border(1.dp, Color(0xFF8B5CF6), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        playedCardsOnTable.forEach { (pIdx, card) ->
                            val cardAlign = when (pIdx) {
                                0 -> Alignment.BottomCenter
                                1 -> Alignment.CenterStart
                                2 -> Alignment.TopCenter
                                else -> Alignment.CenterEnd
                            }
                            Box(modifier = Modifier.align(cardAlign).padding(4.dp)) {
                                PlayingCardView(card = card, isFaceUp = true, modifier = Modifier.size(40.dp, 58.dp))
                            }
                        }

                        if (playedCardsOnTable.isEmpty()) {
                            Text(
                                text = if (turnIndex == 0) "دورك للعب كرت!" else "دور المنافس...",
                                color = Color.LightGray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(text = "كروتك (Your Cards):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(4.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy((-16).dp)
            ) {
                items(playerHand) { card ->
                    PlayingCardView(
                        card = card,
                        isFaceUp = true,
                        onClick = {
                            if (turnIndex == 0 && playedCardsOnTable[0] == null) {
                                playerHand = playerHand - card
                                playedCardsOnTable = playedCardsOnTable + (0 to card)

                                if (playedCardsOnTable.size == 4) {
                                    // evaluate trick
                                } else {
                                    turnIndex = 1
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    if (showModeDialog) {
        GameModeSelectionDialog(
            gameTitle = Localization.getString("game_trix_title", language),
            language = language,
            onSelectMode = { mode, isHost, code ->
                selectedMode = mode
                roomCode = code
                showModeDialog = false
            },
            onDismiss = onBack
        )
    }
}
