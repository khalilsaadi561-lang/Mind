package com.example.util

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    ARABIC("ar", "Arabic", "العربية");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return values().find { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}

object Localization {

    fun getString(key: String, language: AppLanguage): String {
        val isAr = language == AppLanguage.ARABIC
        return when (key) {
            "app_name" -> if (isAr) "صدام العقول" else "Mind Clash"
            "slogan" -> if (isAr) "اختبر سرعة عقلك وذكائك وحظك!" else "Test your speed, knowledge, and luck!"
            
            // Navigation
            "nav_home" -> if (isAr) "الرئيسية" else "Home"
            "nav_store" -> if (isAr) "المتجر" else "Store"
            "nav_leaderboard" -> if (isAr) "المتصدرون" else "Leaderboard"
            "nav_settings" -> if (isAr) "الإعدادات" else "Settings"

            // Games titles & descriptions
            "game_reflex_title" -> if (isAr) "اختبار السرعة والتفاعل" else "Speed & Reflex Test"
            "game_reflex_subtitle" -> if (isAr) "اضغط الفائز (Tap & Win)" else "Tap & Win Challenge"
            "game_reflex_desc" -> if (isAr) "انقر على الأشكال المستهدفة بأسرع وقت ممكن قبل انتهاء العداد!" else "Tap the designated target shapes as quickly as possible before time runs out!"

            "game_trivia_title" -> if (isAr) "سيد الأسئلة والكلمات" else "Guessing Master Trivia"
            "game_trivia_subtitle" -> if (isAr) "تحدي 4 خيارات" else "4-Option Quiz Challenge"
            "game_trivia_desc" -> if (isAr) "أجب على الأسئلة المتنوعة وحقق أعلى النقاط بسرعة إجابتك!" else "Answer fun questions across multiple categories with time-boosted scores!"

            "game_dice_title" -> if (isAr) "تحدي النرد السريع" else "Quick Dice Challenge"
            "game_dice_subtitle" -> if (isAr) "مخاطرة ورمي النرد" else "Risk & Roll Battle"
            "game_dice_desc" -> if (isAr) "ارمي النرد واجمع النقاط، ولكن احذر الرقم 1 لتجنب خسارة الجولة!" else "Roll dice to build round points! Avoid rolling a 1 or lose your round bank!"

            "play_now" -> if (isAr) "العب الآن" else "Play Now"
            "high_score" -> if (isAr) "أعلى نتيجة" else "High Score"
            "coins_label" -> if (isAr) "العملات" else "Coins"

            // Store
            "store_title" -> if (isAr) "متجر صدام العقول" else "Mind Clash Store"
            "store_subtitle" -> if (isAr) "احصل على حزم العملات والميزات الحصرية!" else "Unlock coin packs, remove ads, and get VIP rewards!"
            "remove_ads" -> if (isAr) "إزالة الإعلانات" else "Remove Ads"
            "remove_ads_desc" -> if (isAr) "إلغاء جميع الإعلانات المنبثقة والشريطية للأبد" else "Disables banner & interstitial ads permanently"
            "small_coins" -> if (isAr) "حزمة عملات صغيرة" else "Small Coin Pack"
            "small_coins_desc" -> if (isAr) "احصل على 500 عملة ذهبية" else "Get 500 Gold Coins instantly"
            "mega_coins" -> if (isAr) "حزمة عملات ضخمة" else "Mega Coin Pack"
            "mega_coins_desc" -> if (isAr) "احصل على 2500 عملة ذهبية" else "Get 2500 Gold Coins instantly"
            "vip_pass" -> if (isAr) "اشتراك VIP المميز" else "VIP Pass"
            "vip_pass_desc" -> if (isAr) "إزالة الإعلانات + 1000 عملة مجاناً + إطار ذهبي ملكي في قائمة المتصدرين!" else "Includes Remove Ads + 1000 Bonus Coins + Exclusive Gold Leaderboard Frame!"
            "free_coins_ad" -> if (isAr) "شاهد إعلاناً (100+ عملة)" else "Watch Rewarded Ad (+100 Coins)"
            "free_coins_desc" -> if (isAr) "احصل على 100 عملة مجانية بمشاهدة فيديو قصير" else "Earn 100 free coins by watching a quick short video"
            "buy_btn" -> if (isAr) "شراء" else "Buy"
            "purchased" -> if (isAr) "تم الشراء" else "Purchased"
            "vip_active" -> if (isAr) "VIP مفعل" else "VIP Active"

            // Leaderboard
            "leaderboard_title" -> if (isAr) "لائحة المتصدرين العالمية" else "Global Leaderboard"
            "filter_all" -> if (isAr) "الكل" else "All Games"
            "filter_reflex" -> if (isAr) "السرعة" else "Speed Test"
            "filter_trivia" -> if (isAr) "الأسئلة" else "Trivia"
            "filter_dice" -> if (isAr) "النرد" else "Quick Dice"
            "rank_label" -> if (isAr) "الترتيب" else "Rank"
            "player_label" -> if (isAr) "اللاعب" else "Player"
            "score_label" -> if (isAr) "النقاط" else "Score"
            "you_label" -> if (isAr) "(أنت)" else "(You)"

            // Settings & Theme
            "settings_title" -> if (isAr) "الإعدادات" else "Settings"
            "lang_select" -> if (isAr) "تبديل اللغة (Language Switcher)" else "Language Switcher"
            "theme_select" -> if (isAr) "المظهر والوضع الداكن" else "App Theme & Dark Mode"
            "theme_dark" -> if (isAr) "الوضع الداكن 🌙" else "Midnight Dark 🌙"
            "theme_amoled" -> if (isAr) "الأسود الفائق 🖤" else "AMOLED Black 🖤"
            "theme_light" -> if (isAr) "الوضع الفاتح ☀️" else "Light Neon ☀️"
            "profile_section" -> if (isAr) "الملف الشخصي" else "Player Profile"
            "username_label" -> if (isAr) "اسم المستخدم" else "Username"
            "avatar_label" -> if (isAr) "أيقونة اللاعب" else "Avatar Symbol"
            "sound_fx" -> if (isAr) "المؤثرات الصوتية" else "Sound Effects & Haptics"
            "ad_status" -> if (isAr) "حالة الإعلانات" else "AdMob Status"
            "ads_active" -> if (isAr) "الإعلانات مفعّلة" else "Ads Enabled"
            "ads_disabled" -> if (isAr) "تمت إزالة الإعلانات (VIP/AdFree)" else "Ads Removed (VIP/AdFree)"
            "save_changes" -> if (isAr) "حفظ التغييرات" else "Save Changes"

            // Card Games
            "game_tarneeb_title" -> if (isAr) "لعبة طرنيب (Tarneeb)" else "Tarneeb 41 Card Battle"
            "game_tarneeb_desc" -> if (isAr) "لعبة الشدة العربية الشهيرة للشركاء (2 ضد 2). زايد على الطلب واربح الأكلات!" else "Classic 4-player team card battle! Bid the contract and win tricks!"

            "game_trix_title" -> if (isAr) "لعبة تركس وكومبلكس (Trix)" else "Trix & Complex Cards"
            "game_trix_desc" -> if (isAr) "تركس كلاسيك، تركس كومبلكس، وكومبلكس كومبلكس! تجنب مملكة البنات والشيخ!" else "Classic Trix, Trix Complex, and Complex Complex! Avoid negative contracts!"

            "game_hand_title" -> if (isAr) "لعبة هاند رامي (Hand Cards)" else "Hand Rummy Challenge"
            "game_hand_desc" -> if (isAr) "اجمع المجموعات والمتتاليات ورتب كروتك لتنزيل الهاند قبل المنافسين!" else "Form runs and sets to meld your hand and win the round!"

            // Game Modes (Online vs Bots)
            "select_mode" -> if (isAr) "اختر نظام اللعب" else "Select Game Mode"
            "mode_bots" -> if (isAr) "لعب ضد البوتات 🤖" else "Play vs Smart AI 🤖"
            "mode_bots_desc" -> if (isAr) "مواجهة فورية ضد 3 بوتات أذكياء" else "Instant offline battle vs 3 AI bots"
            "mode_online" -> if (isAr) "غرف أونلاين حية 🌐" else "Online Live Rooms 🌐"
            "mode_online_desc" -> if (isAr) "لعب مباشر مع لاعبين حقيقيين وغرف خاصة" else "Play live with real online players & custom rooms"
            "quick_join" -> if (isAr) "انضمام سريع" else "Quick Match"
            "create_room" -> if (isAr) "إنشاء غرفة خاصة" else "Create Private Room"
            "enter_room_code" -> if (isAr) "أدخل رمز الغرفة" else "Enter Room Code"
            "room_code" -> if (isAr) "رمز الغرفة" else "Room Code"
            "waiting_players" -> if (isAr) "بانتظار اكتمال اللاعبين..." else "Waiting for players..."
            "start_match" -> if (isAr) "بدء المواجهة" else "Start Match"

            // Card Game Gameplay
            "bid_phase" -> if (isAr) "مرحلة الطلب (المزايدة)" else "Bidding Phase"
            "pass" -> if (isAr) "باس (تمرير)" else "Pass"
            "trump_suit" -> if (isAr) "الطرنيب" else "Trump Suit"
            "current_bid" -> if (isAr) "الطلب الحالي" else "Current Contract"
            "your_turn" -> if (isAr) "دورك الآن!" else "Your Turn!"
            "bot_turn" -> if (isAr) "دور المنافس..." else "Bot/Player Thinking..."
            "tricks_won" -> if (isAr) "الأكلات" else "Tricks Won"
            "complex_mode" -> if (isAr) "وضع الكومبلكس" else "Complex Mode"
            "complex_complex" -> if (isAr) "كومبلكس كومبلكس" else "Complex Complex Mode"
            "trix_ladder" -> if (isAr) "تريكس الطلوع" else "Trix Ladder"
            "meld_cards" -> if (isAr) "تنزيل (Meld)" else "Meld Sets"
            "draw_card" -> if (isAr) "سحب كرت" else "Draw Card"
            "discard_card" -> if (isAr) "رمي كرت" else "Discard"

            // Common Game Strings
            "game_over" -> if (isAr) "انتهت اللعبة!" else "Game Over!"
            "round_score" -> if (isAr) "نقاط الجولة" else "Round Score"
            "combo_bonus" -> if (isAr) "مكافأة السلسلة" else "Combo Bonus"
            "reaction_time" -> if (isAr) "زمن الاستجابة" else "Reaction Time"
            "streak" -> if (isAr) "السلسلة" else "Streak"
            "play_again" -> if (isAr) "إعادة اللعب" else "Play Again"
            "submit_score" -> if (isAr) "تسجيل النتيجة" else "Submit Score"
            "back_to_menu" -> if (isAr) "القائمة الرئيسية" else "Main Menu"
            "coins_earned" -> if (isAr) "العملات المكتسبة" else "Coins Earned"

            // Trivia specifics
            "category" -> if (isAr) "الفئة" else "Category"
            "lifeline_5050" -> if (isAr) "حذف إجابتين (50 عملة)" else "50/50 Hint (50 Coins)"
            "lifeline_time" -> if (isAr) "+10 ثواني (30 عملة)" else "+10s Time (30 Coins)"
            "correct_ans" -> if (isAr) "إجابة صحيحة!" else "Correct Answer!"
            "wrong_ans" -> if (isAr) "إجابة خاطئة!" else "Wrong Answer!"

            // Dice specifics
            "roll_dice" -> if (isAr) "ارمي النرد!" else "Roll Dice!"
            "hold_points" -> if (isAr) "احتفظ بالنقاط" else "Bank Points"
            "round_bank" -> if (isAr) "بنك الجولة" else "Round Bank"
            "total_score" -> if (isAr) "المجموع الكلي" else "Total Score"
            "rolled_one" -> if (isAr) "ظهر الرقم 1! خسرت نقاط الجولة!" else "Rolled a 1! Lost round points!"

            else -> key
        }
    }
}
