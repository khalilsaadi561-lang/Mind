package com.example.ui.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay

enum class GameModeType {
    BOTS, ONLINE
}

data class OnlinePlayer(
    val name: String,
    val avatar: String,
    val isReady: Boolean = false,
    val isHost: Boolean = false
)

@Composable
fun GameModeSelectionDialog(
    gameTitle: String,
    language: AppLanguage,
    onSelectMode: (mode: GameModeType, isHost: Boolean, roomCode: String) -> Unit,
    onDismiss: () -> Unit
) {
    var currentStep by remember { mutableStateOf("SELECT_MODE") } // "SELECT_MODE", "ONLINE_SETUP", "LOBBY"
    var enteredRoomCode by remember { mutableStateOf("") }
    var activeRoomCode by remember { mutableStateOf("MC-7892") }
    var isSearchingMatch by remember { mutableStateOf(false) }

    val mockPlayers = remember {
        mutableStateOf(
            listOf(
                OnlinePlayer("أنت (You)", "brain_neon", isReady = true, isHost = true)
            )
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
                        )
                    )
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = gameTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
                Text(
                    text = Localization.getString("select_mode", language),
                    fontSize = 13.sp,
                    color = Color(0xFF00F0FF),
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (currentStep == "SELECT_MODE") {
                    // 1. Play vs AI Bots Option
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectMode(GameModeType.BOTS, false, "")
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E153B)),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(listOf(Color(0xFF00F0FF), Color(0xFF3B82F6)))
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFF00F0FF).copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.SmartToy, contentDescription = null, tint = Color(0xFF00F0FF))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = Localization.getString("mode_bots", language),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = Localization.getString("mode_bots_desc", language),
                                    fontSize = 12.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Play Online Rooms Option
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                currentStep = "ONLINE_SETUP"
                            },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E153B)),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFFEC4899)))
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFFFFD700).copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Public, contentDescription = null, tint = Color(0xFFFFD700))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = Localization.getString("mode_online", language),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = Localization.getString("mode_online_desc", language),
                                    fontSize = 12.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إلغاء (Cancel)")
                    }
                } else if (currentStep == "ONLINE_SETUP") {
                    // Online Setup Screen
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Button(
                            onClick = {
                                isSearchingMatch = true
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            Icon(Icons.Default.Group, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(Localization.getString("quick_join", language), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                activeRoomCode = "ROOM-${(1000..9999).random()}"
                                currentStep = "LOBBY"
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))
                        ) {
                            Icon(Icons.Default.AddCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(Localization.getString("create_room", language), fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "— OR ENTER ROOM CODE —",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = enteredRoomCode,
                            onValueChange = { enteredRoomCode = it.uppercase() },
                            placeholder = { Text("e.g. ROOM-4521") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFFFD700),
                                unfocusedBorderColor = Color(0xFF334155)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                if (enteredRoomCode.isNotBlank()) {
                                    activeRoomCode = enteredRoomCode
                                    currentStep = "LOBBY"
                                }
                            },
                            enabled = enteredRoomCode.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700))
                        ) {
                            Text("انضمام للغرفة (Join)", color = Color.Black, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (isSearchingMatch) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color(0xFF00F0FF)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = Localization.getString("waiting_players", language),
                                    color = Color(0xFF00F0FF),
                                    fontSize = 13.sp
                                )
                            }

                            LaunchedEffect(Unit) {
                                delay(2000)
                                isSearchingMatch = false
                                currentStep = "LOBBY"
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { currentStep = "SELECT_MODE" },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("رجوع (Back)")
                        }
                    }
                } else if (currentStep == "LOBBY") {
                    // Lobby with 4 Players Simulation
                    Text(
                        text = "${Localization.getString("room_code", language)}: $activeRoomCode",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFD700),
                        fontSize = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    LaunchedEffect(Unit) {
                        delay(1200)
                        mockPlayers.value = mockPlayers.value + OnlinePlayer("أحمد (Ahmed)", "lightning", isReady = true)
                        delay(1500)
                        mockPlayers.value = mockPlayers.value + OnlinePlayer("مريم (Mariam)", "crown", isReady = true)
                        delay(1200)
                        mockPlayers.value = mockPlayers.value + OnlinePlayer("خالد (Khaled)", "ninja", isReady = true)
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        mockPlayers.value.forEachIndexed { idx, player ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF1E153B), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "👤 Player ${idx + 1}: ", color = Color.Gray, fontSize = 12.sp)
                                Text(
                                    text = player.name,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = if (player.isReady) "READY ✅" else "WAITING...",
                                    color = if (player.isReady) Color(0xFF10B981) else Color.Yellow,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val isFull = mockPlayers.value.size >= 4

                    Button(
                        onClick = {
                            onSelectMode(GameModeType.ONLINE, true, activeRoomCode)
                        },
                        enabled = isFull,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text(
                            text = if (isFull) Localization.getString("start_match", language) else "بانتظار 4 لاعبين (${mockPlayers.value.size}/4)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
