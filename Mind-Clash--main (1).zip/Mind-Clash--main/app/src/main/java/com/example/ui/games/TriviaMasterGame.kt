package com.example.ui.games

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Filter2
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay

data class QuizQuestion(
    val id: Int,
    val categoryEn: String,
    val categoryAr: String,
    val questionEn: String,
    val questionAr: String,
    val optionsEn: List<String>,
    val optionsAr: List<String>,
    val correctIndex: Int
)

@Composable
fun TriviaMasterGame(
    language: AppLanguage,
    userCoins: Int,
    onSpendCoins: (amount: Int) -> Boolean,
    onGameFinished: (score: Int) -> Unit,
    onBack: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC

    val questions = remember {
        listOf(
            QuizQuestion(
                id = 1,
                categoryEn = "General Knowledge",
                categoryAr = "معلومات عامة",
                questionEn = "Which planet in our solar system is known as the Red Planet?",
                questionAr = "أي كوكب في مجموعتنا الشمسية يُعرف بالكوكب الأحمر؟",
                optionsEn = listOf("Venus", "Mars", "Jupiter", "Saturn"),
                optionsAr = listOf("الزهرة", "المريخ", "المشتري", "زحل"),
                correctIndex = 1
            ),
            QuizQuestion(
                id = 2,
                categoryEn = "Science & Tech",
                categoryAr = "علوم وتكنولوجيا",
                questionEn = "What is the chemical symbol for Gold?",
                questionAr = "ما هو الرمز الكيميائي للذهب؟",
                optionsEn = listOf("Ag", "Fe", "Au", "Cu"),
                optionsAr = listOf("Ag", "Fe", "Au", "Cu"),
                correctIndex = 2
            ),
            QuizQuestion(
                id = 3,
                categoryEn = "Word Riddle",
                categoryAr = "أحجية كلمات",
                questionEn = "I speak without a mouth and hear without ears. What am I?",
                questionAr = "أتكلم بلا فم وأسمع بلا آذان. فمن أنا؟",
                optionsEn = listOf("An Echo", "A Shadow", "A Cloud", "A Wind"),
                optionsAr = listOf("الصدى", "الظل", "الغمامة", "الريح"),
                correctIndex = 0
            ),
            QuizQuestion(
                id = 4,
                categoryEn = "Gaming & Pop",
                categoryAr = "ألعاب وثقافة",
                questionEn = "Which legendary mobile game features birds launched from a slingshot?",
                questionAr = "أي لعبة موبايل شهيرة تعتمد على إطلاق الطيور بالمقلاع؟",
                optionsEn = listOf("Subway Surfers", "Angry Birds", "Flappy Bird", "Fruit Ninja"),
                optionsAr = listOf("سوبواي سيرفرز", "أنغري بيردز", "فلابي بيرد", "فروت نينجا"),
                correctIndex = 1
            ),
            QuizQuestion(
                id = 5,
                categoryEn = "Brain Teaser",
                categoryAr = "تنشيط العقل",
                questionEn = "What has keyhole but no locks, space but no room, enter but no door?",
                questionAr = "ما هو الشيء الذي يحوي أزراراً ومفاتيح ولا يفتح باباً؟",
                optionsEn = listOf("Piano", "Keyboard", "Map", "Clock"),
                optionsAr = listOf("البيانو", "لوحة المفاتيح", "الخريطة", "الساعة"),
                correctIndex = 1
            ),
            QuizQuestion(
                id = 6,
                categoryEn = "General Knowledge",
                categoryAr = "معلومات عامة",
                questionEn = "How many colors are in a standard rainbow?",
                questionAr = "كم عدد ألوان قوس قزح الأساسية؟",
                optionsEn = listOf("5", "6", "7", "8"),
                optionsAr = listOf("5", "6", "7", "8"),
                correctIndex = 2
            )
        )
    }

    var questionIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var timeLeftSeconds by remember { mutableIntStateOf(15) }
    var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
    var isAnswered by remember { mutableStateOf(false) }
    var gameState by remember { mutableStateOf("PLAYING") } // PLAYING, GAMEOVER
    var disabledOptions = remember { mutableStateListOf<Int>() }
    var feedbackMsg by remember { mutableStateOf("") }

    val currentQ = questions[questionIndex % questions.size]

    // Countdown timer for each question
    LaunchedEffect(questionIndex, isAnswered, gameState) {
        if (!isAnswered && gameState == "PLAYING") {
            while (timeLeftSeconds > 0 && !isAnswered) {
                delay(1000)
                timeLeftSeconds--
            }
            if (timeLeftSeconds <= 0 && !isAnswered) {
                // Time up!
                isAnswered = true
                streak = 0
                feedbackMsg = if (isAr) "انتهى الوقت!" else "Time Up!"
            }
        }
    }

    fun submitAnswer(index: Int) {
        if (isAnswered) return
        selectedOptionIndex = index
        isAnswered = true

        if (index == currentQ.correctIndex) {
            streak++
            val timeBonus = timeLeftSeconds * 20
            val qScore = 300 + timeBonus + (streak * 50)
            score += qScore
            feedbackMsg = if (isAr) "إجابة صحيحة! +$qScore" else "Correct! +$qScore Pts"
        } else {
            streak = 0
            feedbackMsg = if (isAr) "إجابة خاطئة!" else "Wrong Answer!"
        }
    }

    fun nextQuestion() {
        if (questionIndex + 1 < questions.size) {
            questionIndex++
            selectedOptionIndex = null
            isAnswered = false
            timeLeftSeconds = 15
            disabledOptions.clear()
            feedbackMsg = ""
        } else {
            gameState = "GAMEOVER"
            onGameFinished(score)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F0B1E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF230D42), Color(0xFF0F0B1E))
                    )
                )
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = Localization.getString("game_trivia_title", language),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .background(Color(0xFF3B1373), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "🏆 $score",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFD700),
                        fontSize = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (gameState == "PLAYING") {
                // Status Progress
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Question ${questionIndex + 1}/${questions.size}",
                        color = Color.LightGray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (isAr) currentQ.categoryAr else currentQ.categoryEn,
                        color = Color(0xFF00F0FF),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Timer Bar
                LinearProgressIndicator(
                    progress = { (timeLeftSeconds / 15f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (timeLeftSeconds > 5) Color(0xFF10B981) else Color(0xFFFF007A),
                    trackColor = Color(0xFF334155)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Lifelines Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = {
                            if (userCoins >= 50 && disabledOptions.isEmpty() && !isAnswered) {
                                if (onSpendCoins(50)) {
                                    val wrongIndices = (0..3).filter { it != currentQ.correctIndex }
                                    disabledOptions.addAll(wrongIndices.shuffled().take(2))
                                }
                            }
                        },
                        enabled = userCoins >= 50 && disabledOptions.isEmpty() && !isAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF312E81)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Filter2, contentDescription = null, tint = Color(0xFFFFD700))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Localization.getString("lifeline_5050", language),
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = {
                            if (userCoins >= 30 && !isAnswered) {
                                if (onSpendCoins(30)) {
                                    timeLeftSeconds += 10
                                }
                            }
                        },
                        enabled = userCoins >= 30 && !isAnswered,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF065F46)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF00F0FF))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Localization.getString("lifeline_time", language),
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Question Box
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1133)),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xFF6366F1), Color(0xFFEC4899))
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isAr) currentQ.questionAr else currentQ.questionEn,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 4 Options Grid/Column
                val options = if (isAr) currentQ.optionsAr else currentQ.optionsEn
                options.forEachIndexed { index, optionText ->
                    val isDisabled = disabledOptions.contains(index)
                    val isSelected = selectedOptionIndex == index
                    val isCorrect = currentQ.correctIndex == index

                    val cardBg = when {
                        isAnswered && isCorrect -> Color(0xFF065F46)
                        isAnswered && isSelected -> Color(0xFF991B1B)
                        else -> Color(0xFF19122B)
                    }

                    val borderColor = when {
                        isAnswered && isCorrect -> Color(0xFF10B981)
                        isAnswered && isSelected -> Color(0xFFEF4444)
                        else -> Color(0xFF3B236E)
                    }

                    if (!isDisabled) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable(enabled = !isAnswered) {
                                    submitAnswer(index)
                                },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.horizontalGradient(listOf(borderColor, borderColor))
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFF2E1B54), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${('A' + index)}",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = optionText,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isAnswered && isCorrect) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF10B981)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (isAnswered) {
                    Text(
                        text = feedbackMsg,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { nextQuestion() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (questionIndex + 1 < questions.size) "Next Question" else "See Results",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            } else {
                // Game Over Screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = Localization.getString("game_over", language),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "TOTAL QUIZ SCORE: $score",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700)
                    )
                    Spacer(modifier = Modifier.height(28.dp))
                    Button(
                        onClick = {
                            questionIndex = 0
                            score = 0
                            streak = 0
                            timeLeftSeconds = 15
                            selectedOptionIndex = null
                            isAnswered = false
                            disabledOptions.clear()
                            gameState = "PLAYING"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Localization.getString("play_again", language))
                    }
                }
            }
        }
    }
}
