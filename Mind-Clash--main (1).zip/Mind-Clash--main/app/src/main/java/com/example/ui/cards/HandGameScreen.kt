package com.example.ui.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HandGameScreen(
    language: AppLanguage,
    onGameFinished: (score: Int) -> Unit,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedMode by remember { mutableStateOf<GameModeType?>(null) }
    var roomCode by remember { mutableStateOf("") }
    var showModeDialog by remember { mutableStateOf(true) }

    var stockPile by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var discardPile by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }

    var playerHand by remember { mutableStateOf<List<PlayingCard>>(emptyList()) }
    var selectedCards by remember { mutableStateOf<Set<PlayingCard>>(emptySet()) }
    var meldedSets by remember { mutableStateOf<List<List<PlayingCard>>>(emptyList()) }

    var hasDrawnThisTurn by remember { mutableStateOf(false) }
    var isPlayerTurn by remember { mutableStateOf(true) }

    var playerScore by remember { mutableIntStateOf(0) }

    fun startNewHand() {
        val fullDeck = generateStandardDeck() + generateStandardDeck()
        stockPile = fullDeck.subList(14, fullDeck.size)
        discardPile = listOf(fullDeck[13])
        playerHand = fullDeck.subList(0, 13).sortedWith(compareBy({ it.suit.ordinal }, { it.rank.ordinal }))
        meldedSets = emptyList()
        selectedCards = emptySet()
        hasDrawnThisTurn = false
        isPlayerTurn = true
    }

    LaunchedEffect(Unit) {
        startNewHand()
    }

    fun handleBotTurn() {
        if (!isPlayerTurn) {
            coroutineScope.launch {
                delay(1200)
                // Bot draws from stock
                if (stockPile.isNotEmpty()) {
                    stockPile = stockPile.drop(1)
                }
                delay(800)
                // Bot discards
                if (stockPile.isNotEmpty()) {
                    discardPile = listOf(stockPile.first()) + discardPile
                }
                isPlayerTurn = true
                hasDrawnThisTurn = false
            }
        }
    }

    LaunchedEffect(isPlayerTurn) {
        handleBotTurn()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F0B1E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF1E1B4B), Color(0xFF0F0B1E)))
                )
                .padding(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = Localization.getString("game_hand_title", language),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 17.sp
                    )
                    Text(
                        text = if (selectedMode == GameModeType.ONLINE) "Online Room: $roomCode 🌐" else "vs AI Bots 🤖",
                        fontSize = 11.sp,
                        color = Color(0xFF00F0FF)
                    )
                }
                IconButton(onClick = { startNewHand() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = Color.White)
                }
            }

            // Playing Table: Stock Pile & Discard Pile
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E153B)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF00F0FF), Color(0xFF8B5CF6)))
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Stock Pile (Draw)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = Localization.getString("draw_card", language), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        PlayingCardView(
                            card = null,
                            isFaceUp = false,
                            onClick = {
                                if (isPlayerTurn && !hasDrawnThisTurn && stockPile.isNotEmpty()) {
                                    val drawnCard = stockPile.first()
                                    stockPile = stockPile.drop(1)
                                    playerHand = (playerHand + drawnCard).sortedWith(compareBy({ it.suit.ordinal }, { it.rank.ordinal }))
                                    hasDrawnThisTurn = true
                                }
                            }
                        )
                        Text(text = "${stockPile.size} left", color = Color.Gray, fontSize = 11.sp)
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(80.dp)
                            .background(Color.Gray)
                    )

                    // Discard Pile
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = Localization.getString("discard_card", language), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        val topDiscard = discardPile.firstOrNull()
                        PlayingCardView(
                            card = topDiscard,
                            isFaceUp = topDiscard != null,
                            onClick = {
                                if (isPlayerTurn && !hasDrawnThisTurn && topDiscard != null) {
                                    discardPile = discardPile.drop(1)
                                    playerHand = (playerHand + topDiscard).sortedWith(compareBy({ it.suit.ordinal }, { it.rank.ordinal }))
                                    hasDrawnThisTurn = true
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Meld / Discard Selected
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = {
                        if (selectedCards.size >= 3) {
                            meldedSets = meldedSets + listOf(selectedCards.toList())
                            playerHand = playerHand - selectedCards
                            selectedCards = emptySet()
                            playerScore += 100
                        }
                    },
                    enabled = isPlayerTurn && selectedCards.size >= 3,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(Localization.getString("meld_cards", language), fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        if (isPlayerTurn && hasDrawnThisTurn && selectedCards.size == 1) {
                            val cardToDiscard = selectedCards.first()
                            playerHand = playerHand - cardToDiscard
                            discardPile = listOf(cardToDiscard) + discardPile
                            selectedCards = emptySet()

                            if (playerHand.isEmpty()) {
                                onGameFinished(playerScore + 1000)
                            } else {
                                isPlayerTurn = false
                            }
                        }
                    },
                    enabled = isPlayerTurn && hasDrawnThisTurn && selectedCards.size == 1,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(Localization.getString("discard_card", language), fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Melded Sets View
            if (meldedSets.isNotEmpty()) {
                Text(text = "المجموعات المُنَزَّلة (Melded Sets):", color = Color(0xFFFFD700), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(meldedSets) { setList ->
                        Row(
                            modifier = Modifier
                                .background(Color(0xFF1E153B), RoundedCornerShape(10.dp))
                                .padding(6.dp)
                        ) {
                            setList.forEach { card ->
                                PlayingCardView(card = card, isFaceUp = true, modifier = Modifier.size(36.dp, 52.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Text(text = "كروتك (Your Hand):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(4.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy((-16).dp)
            ) {
                items(playerHand) { card ->
                    val isSelected = selectedCards.contains(card)
                    PlayingCardView(
                        card = card,
                        isFaceUp = true,
                        isSelected = isSelected,
                        onClick = {
                            selectedCards = if (isSelected) selectedCards - card else selectedCards + card
                        }
                    )
                }
            }
        }
    }

    if (showModeDialog) {
        GameModeSelectionDialog(
            gameTitle = Localization.getString("game_hand_title", language),
            language = language,
            onSelectMode = { mode, isHost, code ->
                selectedMode = mode
                roomCode = code
                showModeDialog = false
            },
            onDismiss = onBack
        )
    }
}
