package com.example.ui.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class CardSuit(val symbol: String, val color: Color) {
    SPADES("♠", Color(0xFF0F172A)),
    HEARTS("♥", Color(0xFFDC2626)),
    DIAMONDS("♦", Color(0xFFDC2626)),
    CLUBS("♣", Color(0xFF0F172A))
}

enum class CardRank(val value: Int, val display: String) {
    TWO(2, "2"), THREE(3, "3"), FOUR(4, "4"), FIVE(5, "5"),
    SIX(6, "6"), SEVEN(7, "7"), EIGHT(8, "8"), NINE(9, "9"),
    TEN(10, "10"), JACK(11, "J"), QUEEN(12, "Q"), KING(13, "K"), ACE(14, "A")
}

data class PlayingCard(
    val suit: CardSuit,
    val rank: CardRank,
    val id: String = "${suit.name}_${rank.name}"
) {
    val isRed: Boolean get() = suit == CardSuit.HEARTS || suit == CardSuit.DIAMONDS
}

@Composable
fun PlayingCardView(
    card: PlayingCard?,
    isFaceUp: Boolean = true,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val widthDp = 54.dp
    val heightDp = 78.dp

    val baseModifier = modifier
        .size(widthDp, heightDp)
        .shadow(if (isSelected) 8.dp else 4.dp, RoundedCornerShape(8.dp))
        .clip(RoundedCornerShape(8.dp))
        .then(
            if (onClick != null) Modifier.clickable { onClick() } else Modifier
        )

    if (card == null || !isFaceUp) {
        // Card Back
        Box(
            modifier = baseModifier
                .background(Color(0xFF1E293B))
                .border(2.dp, Color(0xFF00F0FF), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp, 62.dp)
                    .background(Color(0xFF334155), RoundedCornerShape(4.dp))
                    .border(1.dp, Color(0xFF64748B), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎴", fontSize = 20.sp)
            }
        }
    } else {
        // Face Up Card
        val cardBg = if (isSelected) Color(0xFFFEF08A) else Color.White
        val borderColor = if (isSelected) Color(0xFFEAB308) else Color(0xFFCBD5E1)

        Box(
            modifier = baseModifier
                .background(cardBg)
                .border(if (isSelected) 2.5.dp else 1.dp, borderColor, RoundedCornerShape(8.dp))
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier.align(Alignment.TopStart),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = card.rank.display,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = card.suit.color
                )
                Text(
                    text = card.suit.symbol,
                    fontSize = 11.sp,
                    color = card.suit.color
                )
            }

            // Center Symbol
            Text(
                text = card.suit.symbol,
                fontSize = 22.sp,
                color = card.suit.color,
                modifier = Modifier.align(Alignment.Center)
            )

            Column(
                modifier = Modifier.align(Alignment.BottomEnd),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = card.suit.symbol,
                    fontSize = 11.sp,
                    color = card.suit.color
                )
                Text(
                    text = card.rank.display,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = card.suit.color
                )
            }
        }
    }
}

fun generateStandardDeck(): List<PlayingCard> {
    val deck = mutableListOf<PlayingCard>()
    CardSuit.values().forEach { suit ->
        CardRank.values().forEach { rank ->
            deck.add(PlayingCard(suit, rank))
        }
    }
    deck.shuffle()
    return deck
}
