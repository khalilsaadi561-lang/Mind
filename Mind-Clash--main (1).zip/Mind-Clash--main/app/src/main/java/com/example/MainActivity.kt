package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.GameRepository
import com.example.data.GameStats
import com.example.data.LeaderboardEntry
import com.example.data.UserProfile
import com.example.ui.cards.HandGameScreen
import com.example.ui.cards.TarneebGameScreen
import com.example.ui.cards.TrixGameScreen
import com.example.ui.games.QuickDiceGame
import com.example.ui.games.SpeedReflexGame
import com.example.ui.games.TriviaMasterGame
import com.example.ui.home.HomeScreen
import com.example.ui.leaderboard.LeaderboardScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.store.StoreScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AdMobBannerView
import com.example.util.AdMobManager
import com.example.util.AppLanguage
import com.example.util.Localization
import com.example.util.RewardedAdVideoDialog
import com.example.util.SimulatedInterstitialAdDialog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val repository: GameRepository) : ViewModel() {
    val userProfile: StateFlow<UserProfile> = repository.userProfile.stateInFlow(UserProfile())
    val gameStats: StateFlow<GameStats> = repository.gameStats.stateInFlow(GameStats())

    private val _leaderboardEntries = MutableStateFlow<List<LeaderboardEntry>>(emptyList())
    val leaderboardEntries: StateFlow<List<LeaderboardEntry>> = _leaderboardEntries.asStateFlow()

    init {
        loadLeaderboard("all")
    }

    fun loadLeaderboard(gameType: String) {
        viewModelScope.launch {
            repository.getLeaderboard(gameType).collect { list ->
                _leaderboardEntries.value = list
            }
        }
    }

    fun handlePurchase(itemId: String) {
        viewModelScope.launch {
            when (itemId) {
                "remove_ads" -> repository.setAdRemoved(true)
                "small_coins" -> repository.updateCoins(500)
                "mega_coins" -> repository.updateCoins(2500)
                "vip_pass" -> repository.setVipPass(true)
            }
        }
    }

    fun addRewardedCoins(amount: Int = 100) {
        viewModelScope.launch {
            repository.updateCoins(amount)
        }
    }

    fun spendCoins(amount: Int): Boolean {
        val currentCoins = userProfile.value.coins
        if (currentCoins >= amount) {
            viewModelScope.launch {
                repository.updateCoins(-amount)
            }
            return true
        }
        return false
    }

    fun submitGameScore(score: Int, gameType: String) {
        viewModelScope.launch {
            repository.submitScore(score, gameType)
            repository.updateCoins(score / 10) // Convert score fraction to coins
        }
    }

    fun updateLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.updateLanguage(language.code)
        }
    }

    fun updateThemeMode(theme: String) {
        viewModelScope.launch {
            repository.updateThemeMode(theme)
        }
    }

    fun updateProfile(username: String, avatar: String) {
        viewModelScope.launch {
            repository.updateUsernameAndAvatar(username, avatar)
        }
    }

    private fun <T> kotlinx.coroutines.flow.Flow<T?>.stateInFlow(initial: T): StateFlow<T> {
        val flow = MutableStateFlow(initial)
        viewModelScope.launch {
            collect { value -> if (value != null) flow.value = value }
        }
        return flow.asStateFlow()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = GameRepository(applicationContext)

        setContent {
            val mainViewModel: MainViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        @Suppress("UNCHECKED_CAST")
                        return MainViewModel(repository) as T
                    }
                }
            )

            MyApplicationTheme {
                MindClashApp(mainViewModel)
            }
        }
    }
}

@Composable
fun MindClashApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val userProfile by viewModel.userProfile.collectAsState()
    val gameStats by viewModel.gameStats.collectAsState()
    val leaderboardEntries by viewModel.leaderboardEntries.collectAsState()

    val currentLanguage = AppLanguage.fromCode(userProfile.preferredLanguage)
    val layoutDirection = if (currentLanguage == AppLanguage.ARABIC) LayoutDirection.Rtl else LayoutDirection.Ltr

    var showInterstitial by remember { mutableStateOf(false) }
    var showRewardedAdDialog by remember { mutableStateOf(false) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "home"

    val isPlayingGame = currentRoute.startsWith("game_")

    val appBgColor = when (userProfile.themeMode) {
        "amoled" -> Color(0xFF000000)
        "light" -> Color(0xFF130E26)
        else -> Color(0xFF0F0B1E)
    }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = appBgColor,
            bottomBar = {
                Column(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                    // AdMob Banner View at bottom of game/main screens unless ad is removed
                    AdMobBannerView(isAdRemoved = userProfile.isAdRemoved)

                    // Navigation Bar (shown on main tabs)
                    if (!isPlayingGame) {
                        NavigationBar(
                            containerColor = Color(0xFF140D2B),
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentRoute == "home",
                                onClick = { navController.navigate("home") { popUpTo("home") { inclusive = true } } },
                                icon = { Icon(Icons.Default.Home, contentDescription = null) },
                                label = { Text(Localization.getString("nav_home", currentLanguage), fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF00F0FF),
                                    selectedTextColor = Color(0xFF00F0FF),
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = Color(0xFF241642)
                                )
                            )

                            NavigationBarItem(
                                selected = currentRoute == "store",
                                onClick = { navController.navigate("store") },
                                icon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
                                label = { Text(Localization.getString("nav_store", currentLanguage), fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFFFFD700),
                                    selectedTextColor = Color(0xFFFFD700),
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = Color(0xFF241642)
                                )
                            )

                            NavigationBarItem(
                                selected = currentRoute == "leaderboard",
                                onClick = {
                                    viewModel.loadLeaderboard("all")
                                    navController.navigate("leaderboard")
                                },
                                icon = { Icon(Icons.Default.EmojiEvents, contentDescription = null) },
                                label = { Text(Localization.getString("nav_leaderboard", currentLanguage), fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFFEC4899),
                                    selectedTextColor = Color(0xFFEC4899),
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = Color(0xFF241642)
                                )
                            )

                            NavigationBarItem(
                                selected = currentRoute == "settings",
                                onClick = { navController.navigate("settings") },
                                icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                label = { Text(Localization.getString("nav_settings", currentLanguage), fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFF10B981),
                                    selectedTextColor = Color(0xFF10B981),
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = Color(0xFF241642)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = navController,
                    startDestination = "home"
                ) {
                    composable("home") {
                        HomeScreen(
                            userProfile = userProfile,
                            gameStats = gameStats,
                            language = currentLanguage,
                            onNavigateToGame = { route ->
                                navController.navigate(route)
                            },
                            onNavigateToStore = {
                                navController.navigate("store")
                            }
                        )
                    }

                    composable("store") {
                        StoreScreen(
                            userProfile = userProfile,
                            language = currentLanguage,
                            onPurchaseItem = { itemId ->
                                viewModel.handlePurchase(itemId)
                            },
                            onWatchAdForCoins = {
                                showRewardedAdDialog = true
                            }
                        )
                    }

                    composable("leaderboard") {
                        LeaderboardScreen(
                            entries = leaderboardEntries,
                            language = currentLanguage,
                            onFilterChanged = { filter ->
                                viewModel.loadLeaderboard(filter)
                            }
                        )
                    }

                    composable("settings") {
                        SettingsScreen(
                            userProfile = userProfile,
                            language = currentLanguage,
                            onLanguageChanged = { newLang ->
                                viewModel.updateLanguage(newLang)
                            },
                            onThemeChanged = { theme ->
                                viewModel.updateThemeMode(theme)
                            },
                            onUpdateProfile = { username, avatar ->
                                viewModel.updateProfile(username, avatar)
                            }
                        )
                    }

                    // Card Games
                    composable("game_tarneeb") {
                        TarneebGameScreen(
                            language = currentLanguage,
                            onGameFinished = { score ->
                                viewModel.submitGameScore(score, "tarneeb")
                                if (!userProfile.isAdRemoved) {
                                    showInterstitial = true
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("game_trix") {
                        TrixGameScreen(
                            language = currentLanguage,
                            onGameFinished = { score ->
                                viewModel.submitGameScore(score, "trix")
                                if (!userProfile.isAdRemoved) {
                                    showInterstitial = true
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("game_hand") {
                        HandGameScreen(
                            language = currentLanguage,
                            onGameFinished = { score ->
                                viewModel.submitGameScore(score, "hand")
                                if (!userProfile.isAdRemoved) {
                                    showInterstitial = true
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    // Mini Games
                    composable("game_reflex") {
                        SpeedReflexGame(
                            language = currentLanguage,
                            onGameFinished = { score ->
                                viewModel.submitGameScore(score, "reflex")
                                if (!userProfile.isAdRemoved) {
                                    showInterstitial = true
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("game_trivia") {
                        TriviaMasterGame(
                            language = currentLanguage,
                            userCoins = userProfile.coins,
                            onSpendCoins = { amount ->
                                viewModel.spendCoins(amount)
                            },
                            onGameFinished = { score ->
                                viewModel.submitGameScore(score, "trivia")
                                if (!userProfile.isAdRemoved) {
                                    showInterstitial = true
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("game_dice") {
                        QuickDiceGame(
                            language = currentLanguage,
                            onGameFinished = { score ->
                                viewModel.submitGameScore(score, "dice")
                                if (!userProfile.isAdRemoved) {
                                    showInterstitial = true
                                }
                            },
                            onBack = { navController.popBackStack() }
                        )
                    }
                }

                // Interstitial Ad Overlay
                SimulatedInterstitialAdDialog(
                    show = showInterstitial,
                    onAdDismissed = { showInterstitial = false }
                )

                // Rewarded Ad Dialog for Free Coins
                RewardedAdVideoDialog(
                    show = showRewardedAdDialog,
                    language = currentLanguage,
                    onRewardEarned = {
                        viewModel.addRewardedCoins(100)
                    },
                    onDismiss = { showRewardedAdDialog = false }
                )
            }
        }
    }
}
