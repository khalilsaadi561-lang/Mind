package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val username: String = "MindPlayer",
    val avatarId: String = "brain_neon",
    val coins: Int = 100,
    val isAdRemoved: Boolean = false,
    val hasVipPass: Boolean = false,
    val preferredLanguage: String = "en", // "en" or "ar"
    val themeMode: String = "dark" // "dark", "amoled", "light"
)

@Entity(tableName = "leaderboard_entry")
data class LeaderboardEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val score: Int,
    val gameType: String, // "reflex", "trivia", "dice", "overall"
    val dateTimestamp: Long = System.currentTimeMillis(),
    val isVip: Boolean = false,
    val avatarId: String = "brain_neon"
)

@Entity(tableName = "game_stats")
data class GameStats(
    @PrimaryKey val id: Int = 1,
    val reflexBestScore: Int = 0,
    val reflexBestReactionMs: Long = 999,
    val triviaBestScore: Int = 0,
    val triviaQuestionsAnswered: Int = 0,
    val diceWins: Int = 0,
    val diceBestScore: Int = 0
)

@Dao
interface GameDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getUserProfileDirect(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfile)

    @Query("SELECT * FROM leaderboard_entry ORDER BY score DESC LIMIT 50")
    fun getAllLeaderboard(): Flow<List<LeaderboardEntry>>

    @Query("SELECT * FROM leaderboard_entry WHERE gameType = :gameType ORDER BY score DESC LIMIT 50")
    fun getLeaderboardByGame(gameType: String): Flow<List<LeaderboardEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaderboardEntry(entry: LeaderboardEntry)

    @Query("SELECT * FROM game_stats WHERE id = 1")
    fun getGameStats(): Flow<GameStats?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGameStats(stats: GameStats)
}

@Database(entities = [UserProfile::class, LeaderboardEntry::class, GameStats::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
}
