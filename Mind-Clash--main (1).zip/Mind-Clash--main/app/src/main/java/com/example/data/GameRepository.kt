package com.example.data

import android.content.Context
import android.util.Log
import androidx.room.Room
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class GameRepository(context: Context) {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "mind_clash_db"
    ).fallbackToDestructiveMigration().build()

    private val dao = db.gameDao()
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e("GameRepository", "Firestore initialization fallback: ${e.message}")
            null
        }
    }

    val userProfile: Flow<UserProfile?> = dao.getUserProfile()
    val gameStats: Flow<GameStats?> = dao.getGameStats()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            if (dao.getUserProfileDirect() == null) {
                dao.saveUserProfile(UserProfile())
            }
            if (dao.getGameStats().firstOrNull() == null) {
                dao.saveGameStats(GameStats())
            }
            seedDefaultLeaderboard()
        }
    }

    fun getLeaderboard(gameType: String): Flow<List<LeaderboardEntry>> {
        return if (gameType == "all") {
            dao.getAllLeaderboard()
        } else {
            dao.getLeaderboardByGame(gameType)
        }
    }

    suspend fun updateCoins(delta: Int): UserProfile {
        val current = dao.getUserProfileDirect() ?: UserProfile()
        val newCoins = (current.coins + delta).coerceAtLeast(0)
        val updated = current.copy(coins = newCoins)
        dao.saveUserProfile(updated)
        return updated
    }

    suspend fun setAdRemoved(removed: Boolean) {
        val current = dao.getUserProfileDirect() ?: UserProfile()
        dao.saveUserProfile(current.copy(isAdRemoved = removed))
    }

    suspend fun setVipPass(hasVip: Boolean) {
        val current = dao.getUserProfileDirect() ?: UserProfile()
        val updated = current.copy(
            hasVipPass = hasVip,
            isAdRemoved = true,
            coins = current.coins + 1000
        )
        dao.saveUserProfile(updated)
    }

    suspend fun updateLanguage(lang: String) {
        val current = dao.getUserProfileDirect() ?: UserProfile()
        dao.saveUserProfile(current.copy(preferredLanguage = lang))
    }

    suspend fun updateThemeMode(theme: String) {
        val current = dao.getUserProfileDirect() ?: UserProfile()
        dao.saveUserProfile(current.copy(themeMode = theme))
    }

    suspend fun updateUsernameAndAvatar(name: String, avatar: String) {
        val current = dao.getUserProfileDirect() ?: UserProfile()
        dao.saveUserProfile(current.copy(username = name, avatarId = avatar))
    }

    suspend fun submitScore(score: Int, gameType: String) {
        val profile = dao.getUserProfileDirect() ?: UserProfile()
        val entry = LeaderboardEntry(
            username = profile.username,
            score = score,
            gameType = gameType,
            isVip = profile.hasVipPass,
            avatarId = profile.avatarId
        )
        // 1. Save locally
        dao.insertLeaderboardEntry(entry)

        // 2. Also submit to Firestore if available
        try {
            firestore?.collection("leaderboard")?.add(
                mapOf(
                    "username" to profile.username,
                    "score" to score,
                    "gameType" to gameType,
                    "isVip" to profile.hasVipPass,
                    "avatarId" to profile.avatarId,
                    "timestamp" to System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Log.w("GameRepository", "Firestore submit bypass: ${e.message}")
        }

        // Update personal stats
        val stats = dao.getGameStats().firstOrNull() ?: GameStats()
        when (gameType) {
            "reflex" -> {
                if (score > stats.reflexBestScore) {
                    dao.saveGameStats(stats.copy(reflexBestScore = score))
                }
            }
            "trivia" -> {
                if (score > stats.triviaBestScore) {
                    dao.saveGameStats(stats.copy(triviaBestScore = score))
                }
            }
            "dice" -> {
                if (score > stats.diceBestScore) {
                    dao.saveGameStats(stats.copy(diceBestScore = score))
                }
            }
        }
    }

    suspend fun syncFirestoreLeaderboard() {
        try {
            val snapshot = firestore?.collection("leaderboard")
                ?.orderBy("score", Query.Direction.DESCENDING)
                ?.limit(30)
                ?.get()
                ?.await()

            if (snapshot != null && !snapshot.isEmpty) {
                snapshot.documents.forEach { doc ->
                    val name = doc.getString("username") ?: "MindPlayer"
                    val score = doc.getLong("score")?.toInt() ?: 0
                    val type = doc.getString("gameType") ?: "overall"
                    val isVip = doc.getBoolean("isVip") ?: false
                    val avatar = doc.getString("avatarId") ?: "brain_neon"
                    dao.insertLeaderboardEntry(
                        LeaderboardEntry(
                            username = name,
                            score = score,
                            gameType = type,
                            isVip = isVip,
                            avatarId = avatar
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.d("GameRepository", "Firestore sync info: ${e.message}")
        }
    }

    private suspend fun seedDefaultLeaderboard() {
        val initialEntries = listOf(
            LeaderboardEntry(username = "ReflexKing_99", score = 3850, gameType = "reflex", isVip = true, avatarId = "lightning"),
            LeaderboardEntry(username = "TriviaMaster_AR", score = 3420, gameType = "trivia", isVip = true, avatarId = "crown"),
            LeaderboardEntry(username = "DiceRoller_Pro", score = 2980, gameType = "dice", isVip = false, avatarId = "dice"),
            LeaderboardEntry(username = "MindNinja", score = 2750, gameType = "reflex", isVip = false, avatarId = "ninja"),
            LeaderboardEntry(username = "SmartBrain2026", score = 2600, gameType = "trivia", isVip = false, avatarId = "brain_neon"),
            LeaderboardEntry(username = "LuckyStrike", score = 2410, gameType = "dice", isVip = false, avatarId = "star"),
            LeaderboardEntry(username = "SpeedDemon", score = 2100, gameType = "reflex", isVip = false, avatarId = "lightning"),
            LeaderboardEntry(username = "QuizGenius", score = 1950, gameType = "trivia", isVip = true, avatarId = "crown")
        )
        initialEntries.forEach { dao.insertLeaderboardEntry(it) }
    }
}
