package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProfile
import com.example.util.AppLanguage
import com.example.util.Localization

@Composable
fun SettingsScreen(
    userProfile: UserProfile,
    language: AppLanguage,
    onLanguageChanged: (newLang: AppLanguage) -> Unit,
    onThemeChanged: (theme: String) -> Unit,
    onUpdateProfile: (username: String, avatar: String) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    var usernameInput by remember(userProfile.username) { mutableStateOf(userProfile.username) }
    var selectedAvatar by remember(userProfile.avatarId) { mutableStateOf(userProfile.avatarId) }
    var soundEnabled by remember { mutableStateOf(true) }

    val avatars = listOf("brain_neon", "crown", "lightning", "star", "dice", "ninja")

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F0B1E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF2E1065), Color(0xFF0F0B1E))
                    )
                )
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = Color(0xFF00F0FF),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = Localization.getString("settings_title", language),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 0. Dark Mode / App Theme Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1133)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFF8B5CF6)))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = Localization.getString("theme_select", language),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Midnight Dark
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .background(
                                    if (userProfile.themeMode == "dark") Color(0xFF8B5CF6) else Color(0xFF2B1D4B),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onThemeChanged("dark") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = Localization.getString("theme_dark", language),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        // AMOLED Black
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .background(
                                    if (userProfile.themeMode == "amoled") Color(0xFF00F0FF) else Color(0xFF2B1D4B),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onThemeChanged("amoled") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = Localization.getString("theme_amoled", language),
                                color = if (userProfile.themeMode == "amoled") Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        // Light Neon
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .background(
                                    if (userProfile.themeMode == "light") Color(0xFFFFD700) else Color(0xFF2B1D4B),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onThemeChanged("light") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = Localization.getString("theme_light", language),
                                color = if (userProfile.themeMode == "light") Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Language Switcher Card (English / Arabic)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1133)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF00F0FF), Color(0xFF6366F1)))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = Color(0xFF00F0FF)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Localization.getString("lang_select", language),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // English Option Button
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .padding(end = 6.dp)
                                .background(
                                    if (language == AppLanguage.ENGLISH) Color(0xFF00F0FF) else Color(0xFF2B1D4B),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onLanguageChanged(AppLanguage.ENGLISH) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "English 🇺🇸",
                                color = if (language == AppLanguage.ENGLISH) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        // Arabic Option Button
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .padding(start = 6.dp)
                                .background(
                                    if (language == AppLanguage.ARABIC) Color(0xFFFFD700) else Color(0xFF2B1D4B),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { onLanguageChanged(AppLanguage.ARABIC) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "العربية 🇸🇦",
                                color = if (language == AppLanguage.ARABIC) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Profile Customization Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1133)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF6366F1), Color(0xFFEC4899)))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color(0xFFFFD700)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Localization.getString("profile_section", language),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text(Localization.getString("username_label", language)) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00F0FF),
                            unfocusedBorderColor = Color(0xFF332058)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = Localization.getString("avatar_label", language),
                        fontSize = 13.sp,
                        color = Color.LightGray
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        avatars.forEach { av ->
                            val isSelected = selectedAvatar == av
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(
                                        if (isSelected) Color(0xFFFFD700) else Color(0xFF2D1E50),
                                        CircleShape
                                    )
                                    .border(
                                        if (isSelected) 2.dp else 0.dp,
                                        Color.White,
                                        CircleShape
                                    )
                                    .clickable { selectedAvatar = av },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (av) {
                                        "crown" -> "👑"
                                        "lightning" -> "⚡"
                                        "star" -> "⭐"
                                        "dice" -> "🎲"
                                        "ninja" -> "🥷"
                                        else -> "🧠"
                                    },
                                    fontSize = 20.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onUpdateProfile(usernameInput, selectedAvatar) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Localization.getString("save_changes", language), fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Audio & System Preferences
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1133))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color.LightGray)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = Localization.getString("sound_fx", language),
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        }
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = { soundEnabled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00F0FF))
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Block, contentDescription = null, tint = Color.LightGray)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = Localization.getString("ad_status", language),
                                color = Color.White,
                                fontSize = 15.sp
                            )
                        }
                        Text(
                            text = if (userProfile.isAdRemoved) Localization.getString("ads_disabled", language) else Localization.getString("ads_active", language),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (userProfile.isAdRemoved) Color(0xFF10B981) else Color(0xFFFFD700)
                        )
                    }
                }
            }
        }
    }
}
