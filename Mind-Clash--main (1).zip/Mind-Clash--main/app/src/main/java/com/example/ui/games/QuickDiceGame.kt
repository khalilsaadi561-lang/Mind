package com.example.ui.games

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.AppLanguage
import com.example.util.Localization
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun QuickDiceGame(
    language: AppLanguage,
    onGameFinished: (score: Int) -> Unit,
    onBack: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    val coroutineScope = rememberCoroutineScope()

    var playerScore by remember { mutableIntStateOf(0) }
    var botScore by remember { mutableIntStateOf(0) }
    var currentTurnBank by remember { mutableIntStateOf(0) }
    var diceValue by remember { mutableIntStateOf(1) }
    var isPlayerTurn by remember { mutableStateOf(true) }
    var isRolling by remember { mutableStateOf(false) }
    var gameOver by remember { mutableStateOf(false) }
    var winnerName by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf("Roll the dice to start!") }

    val rotationAnim = remember { Animatable(0f) }

    suspend fun rollDiceAnimation(): Int {
        isRolling = true
        var result = 1
        repeat(8) {
            result = Random.nextInt(1, 7)
            diceValue = result
            rotationAnim.animateTo(
                targetValue = rotationAnim.value + 90f,
                animationSpec = tween(durationMillis = 60)
            )
        }
        isRolling = false
        return result
    }

    // Bot AI Turn Logic
    LaunchedEffect(isPlayerTurn, gameOver) {
        if (!isPlayerTurn && !gameOver) {
            statusText = if (isAr) "دور الروبوت (Bot Turn)..." else "Bot Turn thinking..."
            delay(1000)
            var botRoundBank = 0
            var botRollCount = 0

            while (!isPlayerTurn && !gameOver && botRoundBank < 18 && (botScore + botRoundBank) < 100) {
                val rolled = rollDiceAnimation()
                if (rolled == 1) {
                    botRoundBank = 0
                    statusText = if (isAr) "سقط الروبوت في الرقم 1! خسارة الجولة!" else "Bot rolled a 1! BUST!"
                    delay(1200)
                    isPlayerTurn = true
                    break
                } else {
                    botRoundBank += rolled
                    botRollCount++
                    statusText = if (isAr) "حصل الروبوت على $rolled! بنك الجولة: $botRoundBank" else "Bot rolled $rolled! Round Bank: $botRoundBank"
                    delay(900)

                    if (botScore + botRoundBank >= 100 || botRoundBank >= 15 + Random.nextInt(5)) {
                        botScore += botRoundBank
                        statusText = if (isAr) "احتفظ الروبوت بـ $botRoundBank نقطة!" else "Bot banked $botRoundBank points!"
                        delay(1200)
                        if (botScore >= 100) {
                            gameOver = true
                            winnerName = if (isAr) "الروبوت AI" else "Smart AI Bot"
                            onGameFinished(playerScore)
                        } else {
                            isPlayerTurn = true
                        }
                        break
                    }
                }
            }
        }
    }

    fun handlePlayerRoll() {
        if (!isPlayerTurn || isRolling || gameOver) return

        coroutineScope.launch {
            val rolled = rollDiceAnimation()
            if (rolled == 1) {
                currentTurnBank = 0
                statusText = if (isAr) "ظهر الرقم 1! خسرت بنك هذه الجولة!" else "Rolled a 1! BUST! Lost round points!"
                delay(1200)
                isPlayerTurn = false
            } else {
                currentTurnBank += rolled
                statusText = if (isAr) "حصلت على $rolled! بنك الجولة: $currentTurnBank" else "You rolled $rolled! Round Bank: $currentTurnBank"
            }
        }
    }

    fun handlePlayerHold() {
        if (!isPlayerTurn || isRolling || gameOver || currentTurnBank == 0) return
        playerScore += currentTurnBank
        statusText = if (isAr) "احتفظت بـ $currentTurnBank نقطة!" else "You banked $currentTurnBank points!"
        currentTurnBank = 0

        if (playerScore >= 100) {
            gameOver = true
            winnerName = if (isAr) "أنت (الفائز العظيم)" else "You (Mind Champion)!"
            onGameFinished(playerScore)
        } else {
            isPlayerTurn = false
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                    )
                )
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = Localization.getString("game_dice_title", language),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Scoreboard Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Player Score Box
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isPlayerTurn) Color(0xFF1E1B4B) else Color(0xFF0F172A)),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(if (isPlayerTurn) Color(0xFF00F0FF) else Color(0xFF334155), Color.Transparent)
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isAr) "أنت (You)" else "YOU",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F0FF),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$playerScore / 100",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }

                // Bot Score Box
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = if (!isPlayerTurn) Color(0xFF311042) else Color(0xFF0F172A)),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(if (!isPlayerTurn) Color(0xFFFF007A) else Color(0xFF334155), Color.Transparent)
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SmartToy, contentDescription = null, tint = Color(0xFFFF007A), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "BOT", fontWeight = FontWeight.Bold, color = Color(0xFFFF007A), fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$botScore / 100",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Current Round Bank indicator
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = Localization.getString("round_bank", language),
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = "+$currentTurnBank PTS",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFD700)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 3D Canvas Dice
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .rotate(rotationAnim.value),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val sizePx = size.minDimension
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFFFFFFFF), Color(0xFFE2E8F0))
                        ),
                        cornerRadius = CornerRadius(24.dp.toPx(), 24.dp.toPx()),
                        size = Size(sizePx, sizePx)
                    )

                    val dotRadius = 8.dp.toPx()
                    val dotColor = Color(0xFF0F172A)
                    val p1 = Offset(sizePx * 0.28f, sizePx * 0.28f)
                    val p2 = Offset(sizePx * 0.72f, sizePx * 0.28f)
                    val p3 = Offset(sizePx * 0.50f, sizePx * 0.50f)
                    val p4 = Offset(sizePx * 0.28f, sizePx * 0.72f)
                    val p5 = Offset(sizePx * 0.72f, sizePx * 0.72f)
                    val pLeftMid = Offset(sizePx * 0.28f, sizePx * 0.50f)
                    val pRightMid = Offset(sizePx * 0.72f, sizePx * 0.50f)

                    when (diceValue) {
                        1 -> drawCircle(dotColor, dotRadius * 1.2f, p3)
                        2 -> {
                            drawCircle(dotColor, dotRadius, p1)
                            drawCircle(dotColor, dotRadius, p5)
                        }
                        3 -> {
                            drawCircle(dotColor, dotRadius, p1)
                            drawCircle(dotColor, dotRadius, p3)
                            drawCircle(dotColor, dotRadius, p5)
                        }
                        4 -> {
                            drawCircle(dotColor, dotRadius, p1)
                            drawCircle(dotColor, dotRadius, p2)
                            drawCircle(dotColor, dotRadius, p4)
                            drawCircle(dotColor, dotRadius, p5)
                        }
                        5 -> {
                            drawCircle(dotColor, dotRadius, p1)
                            drawCircle(dotColor, dotRadius, p2)
                            drawCircle(dotColor, dotRadius, p3)
                            drawCircle(dotColor, dotRadius, p4)
                            drawCircle(dotColor, dotRadius, p5)
                        }
                        6 -> {
                            drawCircle(dotColor, dotRadius, p1)
                            drawCircle(dotColor, dotRadius, p2)
                            drawCircle(dotColor, dotRadius, p4)
                            drawCircle(dotColor, dotRadius, p5)
                            drawCircle(dotColor, dotRadius, pLeftMid)
                            drawCircle(dotColor, dotRadius, pRightMid)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = statusText,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.weight(1f))

            if (!gameOver) {
                // Control Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(
                        onClick = { handlePlayerRoll() },
                        enabled = isPlayerTurn && !isRolling,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .padding(end = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Casino, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = Localization.getString("roll_dice", language),
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    Button(
                        onClick = { handlePlayerHold() },
                        enabled = isPlayerTurn && !isRolling && currentTurnBank > 0,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .padding(start = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = Localization.getString("hold_points", language),
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            } else {
                // Game Over Card
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "WINNER: $winnerName",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            playerScore = 0
                            botScore = 0
                            currentTurnBank = 0
                            isPlayerTurn = true
                            gameOver = false
                            statusText = "Roll the dice to start!"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(Localization.getString("play_again", language))
                    }
                }
            }
        }
    }
}
