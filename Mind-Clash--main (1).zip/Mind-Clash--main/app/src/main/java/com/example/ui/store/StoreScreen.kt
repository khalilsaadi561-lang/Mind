package com.example.ui.store

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.UserProfile
import com.example.util.AppLanguage
import com.example.util.Localization

data class StoreItem(
    val id: String,
    val titleKey: String,
    val descKey: String,
    val priceText: String,
    val icon: ImageVector,
    val accentColor: Color,
    val isVip: Boolean = false,
    val coinBonus: Int = 0
)

@Composable
fun StoreScreen(
    userProfile: UserProfile,
    language: AppLanguage,
    onPurchaseItem: (itemId: String) -> Unit,
    onWatchAdForCoins: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC
    var selectedPurchaseItem by remember { mutableStateOf<StoreItem?>(null) }
    var isPurchasing by remember { mutableStateOf(false) }

    val storeItems = remember {
        listOf(
            StoreItem(
                id = "remove_ads",
                titleKey = "remove_ads",
                descKey = "remove_ads_desc",
                priceText = "$0.99",
                icon = Icons.Default.Block,
                accentColor = Color(0xFFEF4444)
            ),
            StoreItem(
                id = "small_coins",
                titleKey = "small_coins",
                descKey = "small_coins_desc",
                priceText = "$0.99",
                icon = Icons.Default.MonetizationOn,
                accentColor = Color(0xFFFFD700),
                coinBonus = 500
            ),
            StoreItem(
                id = "mega_coins",
                titleKey = "mega_coins",
                descKey = "mega_coins_desc",
                priceText = "$2.99",
                icon = Icons.Default.MonetizationOn,
                accentColor = Color(0xFF10B981),
                coinBonus = 2500
            ),
            StoreItem(
                id = "vip_pass",
                titleKey = "vip_pass",
                descKey = "vip_pass_desc",
                priceText = "$4.99",
                icon = Icons.Default.WorkspacePremium,
                accentColor = Color(0xFFFFD700),
                isVip = true,
                coinBonus = 1000
            )
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F0B1E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF2E1065), Color(0xFF0F0B1E))
                    )
                )
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingBag,
                    contentDescription = null,
                    tint = Color(0xFFFFD700),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = Localization.getString("store_title", language),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = Localization.getString("store_subtitle", language),
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                // User Coins Chip
                Box(
                    modifier = Modifier
                        .background(Color(0xFF3B1373), RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFFFFD700), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🪙", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${userProfile.coins}",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFFFD700),
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // VIP Badge Alert if active
            if (userProfile.hasVipPass) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2500)),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFFF59E0B)))
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "VIP MEMBER PASS ACTIVE 👑",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD700),
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Ads Disabled • Gold Frame On Leaderboard",
                                fontSize = 12.sp,
                                color = Color.LightGray
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Free Rewarded Ad Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF00F0FF), Color(0xFF6366F1)))
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF312E81), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.OndemandVideo,
                            contentDescription = null,
                            tint = Color(0xFF00F0FF)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = Localization.getString("free_coins_ad", language),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = Localization.getString("free_coins_desc", language),
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }
                    Button(
                        onClick = onWatchAdForCoins,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Watch",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "FEATURED OFFERS",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Store Item List
            storeItems.forEach { item ->
                val isPurchased = (item.id == "remove_ads" && userProfile.isAdRemoved) ||
                        (item.id == "vip_pass" && userProfile.hasVipPass)

                val cardBg = if (item.isVip) Color(0xFF221500) else Color(0xFF1B1133)
                val borderBrush = if (item.isVip) {
                    Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFFF59E0B)))
                } else {
                    Brush.horizontalGradient(listOf(item.accentColor, Color.Transparent))
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = CardDefaults.outlinedCardBorder().copy(brush = borderBrush)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .background(item.accentColor.copy(alpha = 0.2f), CircleShape)
                                .border(1.dp, item.accentColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = null,
                                tint = item.accentColor,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = Localization.getString(item.titleKey, language),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                if (item.isVip) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "BEST VALUE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black,
                                        modifier = Modifier
                                            .background(Color(0xFFFFD700), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = Localization.getString(item.descKey, language),
                                fontSize = 12.sp,
                                color = Color.LightGray
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { selectedPurchaseItem = item },
                            enabled = !isPurchased,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (item.isVip) Color(0xFFFFD700) else item.accentColor,
                                disabledContainerColor = Color(0xFF334155)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (isPurchased) Localization.getString("purchased", language) else item.priceText,
                                color = if (item.isVip) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Purchase Dialog Confirmation
    selectedPurchaseItem?.let { item ->
        Dialog(onDismissRequest = { if (!isPurchasing) selectedPurchaseItem = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
                            )
                        )
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = null,
                        tint = item.accentColor,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "CONFIRM IN-APP PURCHASE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = Localization.getString(item.titleKey, language),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = Localization.getString(item.descKey, language),
                        fontSize = 13.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Price: ${item.priceText}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFD700)
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { selectedPurchaseItem = null },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                        ) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                isPurchasing = true
                                onPurchaseItem(item.id)
                                isPurchasing = false
                                selectedPurchaseItem = null
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            Text("Confirm", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
